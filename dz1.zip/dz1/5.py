v = int(input('Enter revenue: '))
u = int(input('Enter costs: '))
if v > u:
    print('Very good. You have a profit')
    profitabelity = (v-u)/v*100
    print(f"{profitabelity}% - profitabelity")
elif u > v:
    print("Very bad. You don't have a profit")
else:
    print("You don't have a profit, but damage too")
workers = int(input('How many peoples work for you: '))
print (f'Your PPP - {(v-u)/workers}')
