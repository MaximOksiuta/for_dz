while True:
    number = int(input('Enter number - '))
    if number>999999999999999999999999999999:
        print('Error')
        continue
    else:
        break
divider = 100000000000000000000000000000
record = 0
i = number
while divider > 1:
    divider/=10
    if (i//divider)>record:
        record = i//divider
    i = i % divider
print(f'The largest number - {record}')