record = 3.47
name = "Du Yusheng"
print(f'{name} set a world record for 3x3 Assembly - {record}')
name = input('Your name - ')
record_u = int(input('Your record - '))
print(f'Personal bests of {name} - {record_u}')
