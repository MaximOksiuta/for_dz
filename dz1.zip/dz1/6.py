a = int(input('First results: '))
b = int(input('Dream: '))
results = a
i = 1
while results < b:
    print(f'{i} day - {results}')
    results *= 1.1
    i += 1
print(f'{i} day - {results}')
print(f'on day {i}, the sportsmen reached the desired result')