u_seconds = int(input('Enter seconds - '))
hours = u_seconds//3600
minutes = u_seconds%3600//60
seconds = u_seconds%3600%60
i_hours = hours
i_minutes = minutes
i_seconds = seconds
if hours < 10:
    i_hours = '0'+str(hours)
if hours < 10:
    i_minutes = '0'+str(minutes)
if hours < 10:
    i_seconds = '0'+str(seconds)

print(f'{i_hours}:{i_minutes}:{i_seconds}')